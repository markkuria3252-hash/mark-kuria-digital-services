MARK KURIA DIGITAL SERVICES — VERSION 6
==============================================

Version 6 is a polished international remote-business-support landing site.

NEW IN VERSION 6
-----------------
- Stronger agency-style positioning
- Conversion-focused hero section
- Services overview
- Business value/stat band
- Four-step delivery process
- About / credibility section
- Starting packages
- Client onboarding journey
- Expanded FAQ
- Stronger contact and WhatsApp CTAs
- SEO metadata and mobile-first responsive layout
- Clean dark premium visual system

CONTACT
-------
Mark Kuria
Email: markkuria3252@gmail.com
Phone/WhatsApp: +254 723 554 451
Service area: Worldwide / Remote

IMPORTANT BEFORE PUBLIC LAUNCH
-----------------------------
1. Add a professional headshot or logo.
2. Connect the enquiry form to a real form backend so submissions are stored.
3. Add a real booking calendar link.
4. Add payment links only after the relevant payment accounts are created.
5. Replace generic service wording with verified case studies/results as they become available.
6. Buy/connect your professional domain and SSL hosting.
7. Set up a domain-based business email if desired.
8. Add analytics only after choosing the tracking tools and handling any required consent.
9. Test all buttons/forms on Android, iPhone and desktop.
10. Do not publish unverified testimonials, client logos or performance claims.

The current contact form intentionally uses mailto as a starter implementation; it is not a server-side enquiry database.
